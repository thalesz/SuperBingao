﻿namespace SuperBingao
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.BotaoBola75 = new System.Windows.Forms.Button();
            this.BotaoBola60 = new System.Windows.Forms.Button();
            this.BotaoBola45 = new System.Windows.Forms.Button();
            this.BotaoBola30 = new System.Windows.Forms.Button();
            this.BotaoBola15 = new System.Windows.Forms.Button();
            this.BotaoBola74 = new System.Windows.Forms.Button();
            this.BotaoBola59 = new System.Windows.Forms.Button();
            this.BotaoBola44 = new System.Windows.Forms.Button();
            this.BotaoBola29 = new System.Windows.Forms.Button();
            this.BotaoBola14 = new System.Windows.Forms.Button();
            this.BotaoBola73 = new System.Windows.Forms.Button();
            this.BotaoBola58 = new System.Windows.Forms.Button();
            this.BotaoBola43 = new System.Windows.Forms.Button();
            this.BotaoBola28 = new System.Windows.Forms.Button();
            this.BotaoBola13 = new System.Windows.Forms.Button();
            this.BotaoBola72 = new System.Windows.Forms.Button();
            this.BotaoBola57 = new System.Windows.Forms.Button();
            this.BotaoBola42 = new System.Windows.Forms.Button();
            this.BotaoBola27 = new System.Windows.Forms.Button();
            this.BotaoBola12 = new System.Windows.Forms.Button();
            this.BotaoBola71 = new System.Windows.Forms.Button();
            this.BotaoBola56 = new System.Windows.Forms.Button();
            this.BotaoBola41 = new System.Windows.Forms.Button();
            this.BotaoBola26 = new System.Windows.Forms.Button();
            this.BotaoBola11 = new System.Windows.Forms.Button();
            this.BotaoBola70 = new System.Windows.Forms.Button();
            this.BotaoBola55 = new System.Windows.Forms.Button();
            this.BotaoBola40 = new System.Windows.Forms.Button();
            this.BotaoBola25 = new System.Windows.Forms.Button();
            this.BotaoBola10 = new System.Windows.Forms.Button();
            this.BotaoBola69 = new System.Windows.Forms.Button();
            this.BotaoBola54 = new System.Windows.Forms.Button();
            this.BotaoBola39 = new System.Windows.Forms.Button();
            this.BotaoBola24 = new System.Windows.Forms.Button();
            this.BotaoBola9 = new System.Windows.Forms.Button();
            this.BotaoBola68 = new System.Windows.Forms.Button();
            this.BotaoBola53 = new System.Windows.Forms.Button();
            this.BotaoBola38 = new System.Windows.Forms.Button();
            this.BotaoBola23 = new System.Windows.Forms.Button();
            this.BotaoBola8 = new System.Windows.Forms.Button();
            this.BotaoBola67 = new System.Windows.Forms.Button();
            this.BotaoBola52 = new System.Windows.Forms.Button();
            this.BotaoBola37 = new System.Windows.Forms.Button();
            this.BotaoBola22 = new System.Windows.Forms.Button();
            this.BotaoBola7 = new System.Windows.Forms.Button();
            this.BotaoBola66 = new System.Windows.Forms.Button();
            this.BotaoBola51 = new System.Windows.Forms.Button();
            this.BotaoBola36 = new System.Windows.Forms.Button();
            this.BotaoBola21 = new System.Windows.Forms.Button();
            this.BotaoBola6 = new System.Windows.Forms.Button();
            this.BotaoBola65 = new System.Windows.Forms.Button();
            this.BotaoBola50 = new System.Windows.Forms.Button();
            this.BotaoBola35 = new System.Windows.Forms.Button();
            this.BotaoBola20 = new System.Windows.Forms.Button();
            this.BotaoBola5 = new System.Windows.Forms.Button();
            this.BotaoBola64 = new System.Windows.Forms.Button();
            this.BotaoBola49 = new System.Windows.Forms.Button();
            this.BotaoBola34 = new System.Windows.Forms.Button();
            this.BotaoBola19 = new System.Windows.Forms.Button();
            this.BotaoBola4 = new System.Windows.Forms.Button();
            this.BotaoBola63 = new System.Windows.Forms.Button();
            this.BotaoBola48 = new System.Windows.Forms.Button();
            this.BotaoBola33 = new System.Windows.Forms.Button();
            this.BotaoBola18 = new System.Windows.Forms.Button();
            this.BotaoBola3 = new System.Windows.Forms.Button();
            this.BotaoBola62 = new System.Windows.Forms.Button();
            this.BotaoBola47 = new System.Windows.Forms.Button();
            this.BotaoBola32 = new System.Windows.Forms.Button();
            this.BotaoBola17 = new System.Windows.Forms.Button();
            this.BotaoBola2 = new System.Windows.Forms.Button();
            this.BotaoBola61 = new System.Windows.Forms.Button();
            this.BotaoBola46 = new System.Windows.Forms.Button();
            this.BotaoBola31 = new System.Windows.Forms.Button();
            this.BotaoBola16 = new System.Windows.Forms.Button();
            this.BotaoBola1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.NomeEvento = new System.Windows.Forms.Label();
            this.EdicaoEvento = new System.Windows.Forms.Label();
            this.DescricaoPremio = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TextoDescricaoPremio = new System.Windows.Forms.Label();
            this.TextoEdicao = new System.Windows.Forms.Label();
            this.NumeroPremio = new System.Windows.Forms.Label();
            this.TextoPremio = new System.Windows.Forms.Label();
            this.TempoDecorrido = new System.Windows.Forms.Label();
            this.TextoTempoDecorrido = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.BotaoSairSistema = new System.Windows.Forms.Button();
            this.BotaoSortearBola = new System.Windows.Forms.Button();
            this.OrdemSorteio = new System.Windows.Forms.TextBox();
            this.validacao = new System.Windows.Forms.Panel();
            this.CartelasValidadas = new System.Windows.Forms.ListBox();
            this.BotaoApagarTudo = new System.Windows.Forms.Button();
            this.UltimaValidada = new System.Windows.Forms.Label();
            this.TotalValidada = new System.Windows.Forms.Label();
            this.TextoTotal = new System.Windows.Forms.Label();
            this.Lancamento = new System.Windows.Forms.TextBox();
            this.Lote = new System.Windows.Forms.TextBox();
            this.ValidarCartela = new System.Windows.Forms.TextBox();
            this.TextoUltima = new System.Windows.Forms.Label();
            this.TextoCartelaValidada = new System.Windows.Forms.Label();
            this.TextoLancamento = new System.Windows.Forms.Label();
            this.TextoLtoe = new System.Windows.Forms.Label();
            this.BotaoExportarCSV = new System.Windows.Forms.Button();
            this.TextoValidacao = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.RadioBotaoPedraPedra = new System.Windows.Forms.RadioButton();
            this.radioButton3RadioBotaoAutomatico = new System.Windows.Forms.RadioButton();
            this.RadioBotaoManual = new System.Windows.Forms.RadioButton();
            this.TextoModoSorteio = new System.Windows.Forms.Label();
            this.CaixaInsercaoManual = new System.Windows.Forms.TextBox();
            this.AjustarTempoBola = new System.Windows.Forms.NumericUpDown();
            this.RadioBotaoLinha = new System.Windows.Forms.RadioButton();
            this.RadioBotaoCheia = new System.Windows.Forms.RadioButton();
            this.novoToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.abrirToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.salvarToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.imprimirToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.recortarToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.copiarToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.colarToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.ajudaToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.PainelBarraWindows = new System.Windows.Forms.Panel();
            this.TextoBarraInferior = new System.Windows.Forms.Label();
            this.BotaoEncerrarSorteio = new System.Windows.Forms.Button();
            this.BotaoIniciarPausarSorteio = new System.Windows.Forms.Button();
            this.TextoMarcacao = new System.Windows.Forms.Label();
            this.TextoBolasSorteadas = new System.Windows.Forms.Label();
            this.TextoBolasRestantes = new System.Windows.Forms.Label();
            this.ListaCartelasPeQuente = new System.Windows.Forms.ListBox();
            this.label30 = new System.Windows.Forms.Label();
            this.TotalSorteadas = new System.Windows.Forms.Label();
            this.TotalRestantes = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TextoCartelasPeFrio = new System.Windows.Forms.Label();
            this.ListaCartelasPeFrio = new System.Windows.Forms.ListBox();
            this.BotaoPrepararSorteio = new System.Windows.Forms.Button();
            this.BotaoConferirCartela = new System.Windows.Forms.Button();
            this.TextoApresentar = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.BotaoBrindes = new System.Windows.Forms.Button();
            this.checkBox_Som = new System.Windows.Forms.CheckBox();
            this.checkBox_img = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.PainelUltimaBola = new System.Windows.Forms.Panel();
            this.TextoUltimaBola = new System.Windows.Forms.Label();
            this.ImageLogo = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.validacao.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AjustarTempoBola)).BeginInit();
            this.PainelBarraWindows.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.PainelUltimaBola.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImageLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Gray;
            this.panel1.Controls.Add(this.BotaoBola75);
            this.panel1.Controls.Add(this.BotaoBola60);
            this.panel1.Controls.Add(this.BotaoBola45);
            this.panel1.Controls.Add(this.BotaoBola30);
            this.panel1.Controls.Add(this.BotaoBola15);
            this.panel1.Controls.Add(this.BotaoBola74);
            this.panel1.Controls.Add(this.BotaoBola59);
            this.panel1.Controls.Add(this.BotaoBola44);
            this.panel1.Controls.Add(this.BotaoBola29);
            this.panel1.Controls.Add(this.BotaoBola14);
            this.panel1.Controls.Add(this.BotaoBola73);
            this.panel1.Controls.Add(this.BotaoBola58);
            this.panel1.Controls.Add(this.BotaoBola43);
            this.panel1.Controls.Add(this.BotaoBola28);
            this.panel1.Controls.Add(this.BotaoBola13);
            this.panel1.Controls.Add(this.BotaoBola72);
            this.panel1.Controls.Add(this.BotaoBola57);
            this.panel1.Controls.Add(this.BotaoBola42);
            this.panel1.Controls.Add(this.BotaoBola27);
            this.panel1.Controls.Add(this.BotaoBola12);
            this.panel1.Controls.Add(this.BotaoBola71);
            this.panel1.Controls.Add(this.BotaoBola56);
            this.panel1.Controls.Add(this.BotaoBola41);
            this.panel1.Controls.Add(this.BotaoBola26);
            this.panel1.Controls.Add(this.BotaoBola11);
            this.panel1.Controls.Add(this.BotaoBola70);
            this.panel1.Controls.Add(this.BotaoBola55);
            this.panel1.Controls.Add(this.BotaoBola40);
            this.panel1.Controls.Add(this.BotaoBola25);
            this.panel1.Controls.Add(this.BotaoBola10);
            this.panel1.Controls.Add(this.BotaoBola69);
            this.panel1.Controls.Add(this.BotaoBola54);
            this.panel1.Controls.Add(this.BotaoBola39);
            this.panel1.Controls.Add(this.BotaoBola24);
            this.panel1.Controls.Add(this.BotaoBola9);
            this.panel1.Controls.Add(this.BotaoBola68);
            this.panel1.Controls.Add(this.BotaoBola53);
            this.panel1.Controls.Add(this.BotaoBola38);
            this.panel1.Controls.Add(this.BotaoBola23);
            this.panel1.Controls.Add(this.BotaoBola8);
            this.panel1.Controls.Add(this.BotaoBola67);
            this.panel1.Controls.Add(this.BotaoBola52);
            this.panel1.Controls.Add(this.BotaoBola37);
            this.panel1.Controls.Add(this.BotaoBola22);
            this.panel1.Controls.Add(this.BotaoBola7);
            this.panel1.Controls.Add(this.BotaoBola66);
            this.panel1.Controls.Add(this.BotaoBola51);
            this.panel1.Controls.Add(this.BotaoBola36);
            this.panel1.Controls.Add(this.BotaoBola21);
            this.panel1.Controls.Add(this.BotaoBola6);
            this.panel1.Controls.Add(this.BotaoBola65);
            this.panel1.Controls.Add(this.BotaoBola50);
            this.panel1.Controls.Add(this.BotaoBola35);
            this.panel1.Controls.Add(this.BotaoBola20);
            this.panel1.Controls.Add(this.BotaoBola5);
            this.panel1.Controls.Add(this.BotaoBola64);
            this.panel1.Controls.Add(this.BotaoBola49);
            this.panel1.Controls.Add(this.BotaoBola34);
            this.panel1.Controls.Add(this.BotaoBola19);
            this.panel1.Controls.Add(this.BotaoBola4);
            this.panel1.Controls.Add(this.BotaoBola63);
            this.panel1.Controls.Add(this.BotaoBola48);
            this.panel1.Controls.Add(this.BotaoBola33);
            this.panel1.Controls.Add(this.BotaoBola18);
            this.panel1.Controls.Add(this.BotaoBola3);
            this.panel1.Controls.Add(this.BotaoBola62);
            this.panel1.Controls.Add(this.BotaoBola47);
            this.panel1.Controls.Add(this.BotaoBola32);
            this.panel1.Controls.Add(this.BotaoBola17);
            this.panel1.Controls.Add(this.BotaoBola2);
            this.panel1.Controls.Add(this.BotaoBola61);
            this.panel1.Controls.Add(this.BotaoBola46);
            this.panel1.Controls.Add(this.BotaoBola31);
            this.panel1.Controls.Add(this.BotaoBola16);
            this.panel1.Controls.Add(this.BotaoBola1);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.ForeColor = System.Drawing.Color.Silver;
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(999, 339);
            this.panel1.TabIndex = 0;
            //this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // BotaoBola75
            // 
            this.BotaoBola75.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola75.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola75.Location = new System.Drawing.Point(932, 271);
            this.BotaoBola75.Name = "BotaoBola75";
            this.BotaoBola75.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola75.TabIndex = 1;
            this.BotaoBola75.Text = "75";
            this.BotaoBola75.UseVisualStyleBackColor = true;
            this.BotaoBola75.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola60
            // 
            this.BotaoBola60.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola60.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola60.Location = new System.Drawing.Point(932, 205);
            this.BotaoBola60.Name = "BotaoBola60";
            this.BotaoBola60.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola60.TabIndex = 1;
            this.BotaoBola60.Text = "60";
            this.BotaoBola60.UseVisualStyleBackColor = true;
            this.BotaoBola60.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola45
            // 
            this.BotaoBola45.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola45.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola45.Location = new System.Drawing.Point(932, 139);
            this.BotaoBola45.Name = "BotaoBola45";
            this.BotaoBola45.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola45.TabIndex = 1;
            this.BotaoBola45.Text = "45";
            this.BotaoBola45.UseVisualStyleBackColor = true;
            this.BotaoBola45.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola30
            // 
            this.BotaoBola30.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola30.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola30.Location = new System.Drawing.Point(932, 73);
            this.BotaoBola30.Name = "BotaoBola30";
            this.BotaoBola30.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola30.TabIndex = 1;
            this.BotaoBola30.Text = "30";
            this.BotaoBola30.UseVisualStyleBackColor = true;
            this.BotaoBola30.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola15
            // 
            this.BotaoBola15.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola15.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola15.Location = new System.Drawing.Point(932, 7);
            this.BotaoBola15.Name = "BotaoBola15";
            this.BotaoBola15.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola15.TabIndex = 1;
            this.BotaoBola15.Text = "15";
            this.BotaoBola15.UseVisualStyleBackColor = true;
            this.BotaoBola15.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola74
            // 
            this.BotaoBola74.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola74.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola74.Location = new System.Drawing.Point(866, 271);
            this.BotaoBola74.Name = "BotaoBola74";
            this.BotaoBola74.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola74.TabIndex = 1;
            this.BotaoBola74.Text = "74";
            this.BotaoBola74.UseVisualStyleBackColor = true;
            this.BotaoBola74.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola59
            // 
            this.BotaoBola59.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola59.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola59.Location = new System.Drawing.Point(866, 205);
            this.BotaoBola59.Name = "BotaoBola59";
            this.BotaoBola59.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola59.TabIndex = 1;
            this.BotaoBola59.Text = "59";
            this.BotaoBola59.UseVisualStyleBackColor = true;
            this.BotaoBola59.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola44
            // 
            this.BotaoBola44.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola44.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola44.Location = new System.Drawing.Point(866, 139);
            this.BotaoBola44.Name = "BotaoBola44";
            this.BotaoBola44.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola44.TabIndex = 1;
            this.BotaoBola44.Text = "44";
            this.BotaoBola44.UseVisualStyleBackColor = true;
            this.BotaoBola44.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola29
            // 
            this.BotaoBola29.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola29.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola29.Location = new System.Drawing.Point(866, 73);
            this.BotaoBola29.Name = "BotaoBola29";
            this.BotaoBola29.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola29.TabIndex = 1;
            this.BotaoBola29.Text = "29";
            this.BotaoBola29.UseVisualStyleBackColor = true;
            this.BotaoBola29.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola14
            // 
            this.BotaoBola14.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola14.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola14.Location = new System.Drawing.Point(866, 7);
            this.BotaoBola14.Name = "BotaoBola14";
            this.BotaoBola14.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola14.TabIndex = 1;
            this.BotaoBola14.Text = "14";
            this.BotaoBola14.UseVisualStyleBackColor = true;
            this.BotaoBola14.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola73
            // 
            this.BotaoBola73.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola73.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola73.Location = new System.Drawing.Point(800, 271);
            this.BotaoBola73.Name = "BotaoBola73";
            this.BotaoBola73.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola73.TabIndex = 1;
            this.BotaoBola73.Text = "73";
            this.BotaoBola73.UseVisualStyleBackColor = true;
            this.BotaoBola73.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola58
            // 
            this.BotaoBola58.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola58.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola58.Location = new System.Drawing.Point(800, 205);
            this.BotaoBola58.Name = "BotaoBola58";
            this.BotaoBola58.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola58.TabIndex = 1;
            this.BotaoBola58.Text = "58";
            this.BotaoBola58.UseVisualStyleBackColor = true;
            this.BotaoBola58.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola43
            // 
            this.BotaoBola43.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola43.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola43.Location = new System.Drawing.Point(800, 139);
            this.BotaoBola43.Name = "BotaoBola43";
            this.BotaoBola43.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola43.TabIndex = 1;
            this.BotaoBola43.Text = "43";
            this.BotaoBola43.UseVisualStyleBackColor = true;
            this.BotaoBola43.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola28
            // 
            this.BotaoBola28.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola28.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola28.Location = new System.Drawing.Point(800, 73);
            this.BotaoBola28.Name = "BotaoBola28";
            this.BotaoBola28.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola28.TabIndex = 1;
            this.BotaoBola28.Text = "28";
            this.BotaoBola28.UseVisualStyleBackColor = true;
            this.BotaoBola28.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola13
            // 
            this.BotaoBola13.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola13.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola13.Location = new System.Drawing.Point(800, 7);
            this.BotaoBola13.Name = "BotaoBola13";
            this.BotaoBola13.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola13.TabIndex = 1;
            this.BotaoBola13.Text = "13";
            this.BotaoBola13.UseVisualStyleBackColor = true;
            this.BotaoBola13.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola72
            // 
            this.BotaoBola72.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola72.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola72.Location = new System.Drawing.Point(734, 271);
            this.BotaoBola72.Name = "BotaoBola72";
            this.BotaoBola72.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola72.TabIndex = 1;
            this.BotaoBola72.Text = "72";
            this.BotaoBola72.UseVisualStyleBackColor = true;
            this.BotaoBola72.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola57
            // 
            this.BotaoBola57.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola57.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola57.Location = new System.Drawing.Point(734, 205);
            this.BotaoBola57.Name = "BotaoBola57";
            this.BotaoBola57.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola57.TabIndex = 1;
            this.BotaoBola57.Text = "57";
            this.BotaoBola57.UseVisualStyleBackColor = true;
            this.BotaoBola57.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola42
            // 
            this.BotaoBola42.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola42.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola42.Location = new System.Drawing.Point(734, 139);
            this.BotaoBola42.Name = "BotaoBola42";
            this.BotaoBola42.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola42.TabIndex = 1;
            this.BotaoBola42.Text = "42";
            this.BotaoBola42.UseVisualStyleBackColor = true;
            this.BotaoBola42.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola27
            // 
            this.BotaoBola27.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola27.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola27.Location = new System.Drawing.Point(734, 73);
            this.BotaoBola27.Name = "BotaoBola27";
            this.BotaoBola27.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola27.TabIndex = 1;
            this.BotaoBola27.Text = "27";
            this.BotaoBola27.UseVisualStyleBackColor = true;
            this.BotaoBola27.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola12
            // 
            this.BotaoBola12.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola12.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola12.Location = new System.Drawing.Point(734, 7);
            this.BotaoBola12.Name = "BotaoBola12";
            this.BotaoBola12.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola12.TabIndex = 1;
            this.BotaoBola12.Text = "12";
            this.BotaoBola12.UseVisualStyleBackColor = true;
            this.BotaoBola12.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola71
            // 
            this.BotaoBola71.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola71.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola71.Location = new System.Drawing.Point(668, 271);
            this.BotaoBola71.Name = "BotaoBola71";
            this.BotaoBola71.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola71.TabIndex = 1;
            this.BotaoBola71.Text = "71";
            this.BotaoBola71.UseVisualStyleBackColor = true;
            this.BotaoBola71.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola56
            // 
            this.BotaoBola56.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola56.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola56.Location = new System.Drawing.Point(668, 205);
            this.BotaoBola56.Name = "BotaoBola56";
            this.BotaoBola56.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola56.TabIndex = 1;
            this.BotaoBola56.Text = "56";
            this.BotaoBola56.UseVisualStyleBackColor = true;
            this.BotaoBola56.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola41
            // 
            this.BotaoBola41.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola41.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola41.Location = new System.Drawing.Point(668, 139);
            this.BotaoBola41.Name = "BotaoBola41";
            this.BotaoBola41.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola41.TabIndex = 1;
            this.BotaoBola41.Text = "41";
            this.BotaoBola41.UseVisualStyleBackColor = true;
            this.BotaoBola41.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola26
            // 
            this.BotaoBola26.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola26.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola26.Location = new System.Drawing.Point(668, 73);
            this.BotaoBola26.Name = "BotaoBola26";
            this.BotaoBola26.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola26.TabIndex = 1;
            this.BotaoBola26.Text = "26";
            this.BotaoBola26.UseVisualStyleBackColor = true;
            this.BotaoBola26.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola11
            // 
            this.BotaoBola11.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola11.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola11.Location = new System.Drawing.Point(668, 7);
            this.BotaoBola11.Name = "BotaoBola11";
            this.BotaoBola11.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola11.TabIndex = 1;
            this.BotaoBola11.Text = "11";
            this.BotaoBola11.UseVisualStyleBackColor = true;
            this.BotaoBola11.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola70
            // 
            this.BotaoBola70.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola70.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola70.Location = new System.Drawing.Point(602, 271);
            this.BotaoBola70.Name = "BotaoBola70";
            this.BotaoBola70.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola70.TabIndex = 1;
            this.BotaoBola70.Text = "70";
            this.BotaoBola70.UseVisualStyleBackColor = true;
            this.BotaoBola70.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola55
            // 
            this.BotaoBola55.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola55.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola55.Location = new System.Drawing.Point(602, 205);
            this.BotaoBola55.Name = "BotaoBola55";
            this.BotaoBola55.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola55.TabIndex = 1;
            this.BotaoBola55.Text = "55";
            this.BotaoBola55.UseVisualStyleBackColor = true;
            this.BotaoBola55.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola40
            // 
            this.BotaoBola40.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola40.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola40.Location = new System.Drawing.Point(602, 139);
            this.BotaoBola40.Name = "BotaoBola40";
            this.BotaoBola40.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola40.TabIndex = 1;
            this.BotaoBola40.Text = "40";
            this.BotaoBola40.UseVisualStyleBackColor = true;
            this.BotaoBola40.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola25
            // 
            this.BotaoBola25.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola25.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola25.Location = new System.Drawing.Point(602, 73);
            this.BotaoBola25.Name = "BotaoBola25";
            this.BotaoBola25.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola25.TabIndex = 1;
            this.BotaoBola25.Text = "25";
            this.BotaoBola25.UseVisualStyleBackColor = true;
            this.BotaoBola25.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola10
            // 
            this.BotaoBola10.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola10.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola10.Location = new System.Drawing.Point(602, 7);
            this.BotaoBola10.Name = "BotaoBola10";
            this.BotaoBola10.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola10.TabIndex = 1;
            this.BotaoBola10.Text = "10";
            this.BotaoBola10.UseVisualStyleBackColor = true;
            this.BotaoBola10.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola69
            // 
            this.BotaoBola69.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola69.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola69.Location = new System.Drawing.Point(536, 271);
            this.BotaoBola69.Name = "BotaoBola69";
            this.BotaoBola69.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola69.TabIndex = 1;
            this.BotaoBola69.Text = "69";
            this.BotaoBola69.UseVisualStyleBackColor = true;
            this.BotaoBola69.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola54
            // 
            this.BotaoBola54.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola54.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola54.Location = new System.Drawing.Point(536, 205);
            this.BotaoBola54.Name = "BotaoBola54";
            this.BotaoBola54.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola54.TabIndex = 1;
            this.BotaoBola54.Text = "54";
            this.BotaoBola54.UseVisualStyleBackColor = true;
            this.BotaoBola54.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola39
            // 
            this.BotaoBola39.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola39.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola39.Location = new System.Drawing.Point(536, 139);
            this.BotaoBola39.Name = "BotaoBola39";
            this.BotaoBola39.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola39.TabIndex = 1;
            this.BotaoBola39.Text = "39";
            this.BotaoBola39.UseVisualStyleBackColor = true;
            this.BotaoBola39.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola24
            // 
            this.BotaoBola24.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola24.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola24.Location = new System.Drawing.Point(536, 73);
            this.BotaoBola24.Name = "BotaoBola24";
            this.BotaoBola24.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola24.TabIndex = 1;
            this.BotaoBola24.Text = "24";
            this.BotaoBola24.UseVisualStyleBackColor = true;
            this.BotaoBola24.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola9
            // 
            this.BotaoBola9.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola9.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola9.Location = new System.Drawing.Point(536, 7);
            this.BotaoBola9.Name = "BotaoBola9";
            this.BotaoBola9.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola9.TabIndex = 1;
            this.BotaoBola9.Text = "09";
            this.BotaoBola9.UseVisualStyleBackColor = true;
            this.BotaoBola9.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola68
            // 
            this.BotaoBola68.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola68.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola68.Location = new System.Drawing.Point(470, 271);
            this.BotaoBola68.Name = "BotaoBola68";
            this.BotaoBola68.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola68.TabIndex = 1;
            this.BotaoBola68.Text = "68";
            this.BotaoBola68.UseVisualStyleBackColor = true;
            this.BotaoBola68.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola53
            // 
            this.BotaoBola53.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola53.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola53.Location = new System.Drawing.Point(470, 205);
            this.BotaoBola53.Name = "BotaoBola53";
            this.BotaoBola53.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola53.TabIndex = 1;
            this.BotaoBola53.Text = "53";
            this.BotaoBola53.UseVisualStyleBackColor = true;
            this.BotaoBola53.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola38
            // 
            this.BotaoBola38.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola38.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola38.Location = new System.Drawing.Point(470, 139);
            this.BotaoBola38.Name = "BotaoBola38";
            this.BotaoBola38.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola38.TabIndex = 1;
            this.BotaoBola38.Text = "38";
            this.BotaoBola38.UseVisualStyleBackColor = true;
            this.BotaoBola38.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola23
            // 
            this.BotaoBola23.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola23.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola23.Location = new System.Drawing.Point(470, 73);
            this.BotaoBola23.Name = "BotaoBola23";
            this.BotaoBola23.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola23.TabIndex = 1;
            this.BotaoBola23.Text = "23";
            this.BotaoBola23.UseVisualStyleBackColor = true;
            this.BotaoBola23.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola8
            // 
            this.BotaoBola8.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola8.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola8.Location = new System.Drawing.Point(470, 7);
            this.BotaoBola8.Name = "BotaoBola8";
            this.BotaoBola8.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola8.TabIndex = 1;
            this.BotaoBola8.Text = "08";
            this.BotaoBola8.UseVisualStyleBackColor = true;
            this.BotaoBola8.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola67
            // 
            this.BotaoBola67.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola67.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola67.Location = new System.Drawing.Point(404, 271);
            this.BotaoBola67.Name = "BotaoBola67";
            this.BotaoBola67.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola67.TabIndex = 1;
            this.BotaoBola67.Text = "67";
            this.BotaoBola67.UseVisualStyleBackColor = true;
            this.BotaoBola67.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola52
            // 
            this.BotaoBola52.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola52.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola52.Location = new System.Drawing.Point(404, 205);
            this.BotaoBola52.Name = "BotaoBola52";
            this.BotaoBola52.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola52.TabIndex = 1;
            this.BotaoBola52.Text = "52";
            this.BotaoBola52.UseVisualStyleBackColor = true;
            this.BotaoBola52.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola37
            // 
            this.BotaoBola37.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola37.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola37.Location = new System.Drawing.Point(404, 139);
            this.BotaoBola37.Name = "BotaoBola37";
            this.BotaoBola37.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola37.TabIndex = 1;
            this.BotaoBola37.Text = "37";
            this.BotaoBola37.UseVisualStyleBackColor = true;
            this.BotaoBola37.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola22
            // 
            this.BotaoBola22.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola22.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola22.Location = new System.Drawing.Point(404, 73);
            this.BotaoBola22.Name = "BotaoBola22";
            this.BotaoBola22.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola22.TabIndex = 1;
            this.BotaoBola22.Text = "22";
            this.BotaoBola22.UseVisualStyleBackColor = true;
            this.BotaoBola22.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola7
            // 
            this.BotaoBola7.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola7.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola7.Location = new System.Drawing.Point(404, 7);
            this.BotaoBola7.Name = "BotaoBola7";
            this.BotaoBola7.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola7.TabIndex = 1;
            this.BotaoBola7.Text = "07";
            this.BotaoBola7.UseVisualStyleBackColor = true;
            this.BotaoBola7.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola66
            // 
            this.BotaoBola66.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola66.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola66.Location = new System.Drawing.Point(338, 271);
            this.BotaoBola66.Name = "BotaoBola66";
            this.BotaoBola66.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola66.TabIndex = 1;
            this.BotaoBola66.Text = "66";
            this.BotaoBola66.UseVisualStyleBackColor = true;
            this.BotaoBola66.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola51
            // 
            this.BotaoBola51.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola51.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola51.Location = new System.Drawing.Point(338, 205);
            this.BotaoBola51.Name = "BotaoBola51";
            this.BotaoBola51.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola51.TabIndex = 1;
            this.BotaoBola51.Text = "51";
            this.BotaoBola51.UseVisualStyleBackColor = true;
            this.BotaoBola51.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola36
            // 
            this.BotaoBola36.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola36.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola36.Location = new System.Drawing.Point(338, 139);
            this.BotaoBola36.Name = "BotaoBola36";
            this.BotaoBola36.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola36.TabIndex = 1;
            this.BotaoBola36.Text = "36";
            this.BotaoBola36.UseVisualStyleBackColor = true;
            this.BotaoBola36.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola21
            // 
            this.BotaoBola21.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola21.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola21.Location = new System.Drawing.Point(338, 73);
            this.BotaoBola21.Name = "BotaoBola21";
            this.BotaoBola21.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola21.TabIndex = 1;
            this.BotaoBola21.Text = "21";
            this.BotaoBola21.UseVisualStyleBackColor = true;
            this.BotaoBola21.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola6
            // 
            this.BotaoBola6.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola6.ForeColor = System.Drawing.Color.DimGray;
            this.BotaoBola6.Location = new System.Drawing.Point(338, 7);
            this.BotaoBola6.Name = "BotaoBola6";
            this.BotaoBola6.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola6.TabIndex = 1;
            this.BotaoBola6.Text = "06";
            this.BotaoBola6.UseVisualStyleBackColor = true;
            this.BotaoBola6.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola65
            // 
            this.BotaoBola65.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola65.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola65.Location = new System.Drawing.Point(272, 271);
            this.BotaoBola65.Name = "BotaoBola65";
            this.BotaoBola65.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola65.TabIndex = 1;
            this.BotaoBola65.Text = "65";
            this.BotaoBola65.UseVisualStyleBackColor = true;
            this.BotaoBola65.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola50
            // 
            this.BotaoBola50.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola50.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola50.Location = new System.Drawing.Point(272, 205);
            this.BotaoBola50.Name = "BotaoBola50";
            this.BotaoBola50.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola50.TabIndex = 1;
            this.BotaoBola50.Text = "50";
            this.BotaoBola50.UseVisualStyleBackColor = true;
            this.BotaoBola50.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola35
            // 
            this.BotaoBola35.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola35.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola35.Location = new System.Drawing.Point(272, 139);
            this.BotaoBola35.Name = "BotaoBola35";
            this.BotaoBola35.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola35.TabIndex = 1;
            this.BotaoBola35.Text = "35";
            this.BotaoBola35.UseVisualStyleBackColor = true;
            this.BotaoBola35.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola20
            // 
            this.BotaoBola20.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola20.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola20.Location = new System.Drawing.Point(272, 73);
            this.BotaoBola20.Name = "BotaoBola20";
            this.BotaoBola20.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola20.TabIndex = 1;
            this.BotaoBola20.Text = "20";
            this.BotaoBola20.UseVisualStyleBackColor = true;
            this.BotaoBola20.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola5
            // 
            this.BotaoBola5.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola5.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola5.Location = new System.Drawing.Point(272, 7);
            this.BotaoBola5.Name = "BotaoBola5";
            this.BotaoBola5.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola5.TabIndex = 1;
            this.BotaoBola5.Text = "05";
            this.BotaoBola5.UseVisualStyleBackColor = true;
            this.BotaoBola5.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola64
            // 
            this.BotaoBola64.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola64.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola64.Location = new System.Drawing.Point(206, 271);
            this.BotaoBola64.Name = "BotaoBola64";
            this.BotaoBola64.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola64.TabIndex = 1;
            this.BotaoBola64.Text = "64";
            this.BotaoBola64.UseVisualStyleBackColor = true;
            this.BotaoBola64.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola49
            // 
            this.BotaoBola49.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola49.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola49.Location = new System.Drawing.Point(206, 205);
            this.BotaoBola49.Name = "BotaoBola49";
            this.BotaoBola49.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola49.TabIndex = 1;
            this.BotaoBola49.Text = "49";
            this.BotaoBola49.UseVisualStyleBackColor = true;
            this.BotaoBola49.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola34
            // 
            this.BotaoBola34.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola34.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola34.Location = new System.Drawing.Point(206, 139);
            this.BotaoBola34.Name = "BotaoBola34";
            this.BotaoBola34.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola34.TabIndex = 1;
            this.BotaoBola34.Text = "34";
            this.BotaoBola34.UseVisualStyleBackColor = true;
            this.BotaoBola34.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola19
            // 
            this.BotaoBola19.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola19.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola19.Location = new System.Drawing.Point(206, 73);
            this.BotaoBola19.Name = "BotaoBola19";
            this.BotaoBola19.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola19.TabIndex = 1;
            this.BotaoBola19.Text = "19";
            this.BotaoBola19.UseVisualStyleBackColor = true;
            this.BotaoBola19.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola4
            // 
            this.BotaoBola4.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola4.Location = new System.Drawing.Point(206, 7);
            this.BotaoBola4.Name = "BotaoBola4";
            this.BotaoBola4.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola4.TabIndex = 1;
            this.BotaoBola4.Text = "04";
            this.BotaoBola4.UseVisualStyleBackColor = true;
            this.BotaoBola4.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola63
            // 
            this.BotaoBola63.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola63.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola63.Location = new System.Drawing.Point(140, 271);
            this.BotaoBola63.Name = "BotaoBola63";
            this.BotaoBola63.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola63.TabIndex = 1;
            this.BotaoBola63.Text = "63";
            this.BotaoBola63.UseVisualStyleBackColor = true;
            this.BotaoBola63.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola48
            // 
            this.BotaoBola48.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola48.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola48.Location = new System.Drawing.Point(140, 205);
            this.BotaoBola48.Name = "BotaoBola48";
            this.BotaoBola48.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola48.TabIndex = 1;
            this.BotaoBola48.Text = "48";
            this.BotaoBola48.UseVisualStyleBackColor = true;
            this.BotaoBola48.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola33
            // 
            this.BotaoBola33.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola33.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola33.Location = new System.Drawing.Point(140, 139);
            this.BotaoBola33.Name = "BotaoBola33";
            this.BotaoBola33.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola33.TabIndex = 1;
            this.BotaoBola33.Text = "33";
            this.BotaoBola33.UseVisualStyleBackColor = true;
            this.BotaoBola33.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola18
            // 
            this.BotaoBola18.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola18.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola18.Location = new System.Drawing.Point(140, 73);
            this.BotaoBola18.Name = "BotaoBola18";
            this.BotaoBola18.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola18.TabIndex = 1;
            this.BotaoBola18.Text = "18";
            this.BotaoBola18.UseVisualStyleBackColor = true;
            this.BotaoBola18.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola3
            // 
            this.BotaoBola3.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola3.Location = new System.Drawing.Point(140, 7);
            this.BotaoBola3.Name = "BotaoBola3";
            this.BotaoBola3.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola3.TabIndex = 1;
            this.BotaoBola3.Text = "03";
            this.BotaoBola3.UseVisualStyleBackColor = true;
            this.BotaoBola3.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola62
            // 
            this.BotaoBola62.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola62.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola62.Location = new System.Drawing.Point(74, 271);
            this.BotaoBola62.Name = "BotaoBola62";
            this.BotaoBola62.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola62.TabIndex = 1;
            this.BotaoBola62.Text = "62";
            this.BotaoBola62.UseVisualStyleBackColor = true;
            this.BotaoBola62.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola47
            // 
            this.BotaoBola47.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola47.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola47.Location = new System.Drawing.Point(74, 205);
            this.BotaoBola47.Name = "BotaoBola47";
            this.BotaoBola47.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola47.TabIndex = 1;
            this.BotaoBola47.Text = "47";
            this.BotaoBola47.UseVisualStyleBackColor = true;
            this.BotaoBola47.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola32
            // 
            this.BotaoBola32.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola32.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola32.Location = new System.Drawing.Point(74, 139);
            this.BotaoBola32.Name = "BotaoBola32";
            this.BotaoBola32.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola32.TabIndex = 1;
            this.BotaoBola32.Text = "32";
            this.BotaoBola32.UseVisualStyleBackColor = true;
            this.BotaoBola32.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola17
            // 
            this.BotaoBola17.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola17.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola17.Location = new System.Drawing.Point(74, 73);
            this.BotaoBola17.Name = "BotaoBola17";
            this.BotaoBola17.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola17.TabIndex = 1;
            this.BotaoBola17.Text = "17";
            this.BotaoBola17.UseVisualStyleBackColor = true;
            this.BotaoBola17.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola2
            // 
            this.BotaoBola2.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola2.Location = new System.Drawing.Point(74, 7);
            this.BotaoBola2.Name = "BotaoBola2";
            this.BotaoBola2.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola2.TabIndex = 1;
            this.BotaoBola2.Text = "02";
            this.BotaoBola2.UseVisualStyleBackColor = true;
            this.BotaoBola2.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola61
            // 
            this.BotaoBola61.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola61.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola61.Location = new System.Drawing.Point(8, 271);
            this.BotaoBola61.Name = "BotaoBola61";
            this.BotaoBola61.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola61.TabIndex = 1;
            this.BotaoBola61.Text = "61";
            this.BotaoBola61.UseVisualStyleBackColor = true;
            this.BotaoBola61.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola46
            // 
            this.BotaoBola46.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola46.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola46.Location = new System.Drawing.Point(8, 205);
            this.BotaoBola46.Name = "BotaoBola46";
            this.BotaoBola46.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola46.TabIndex = 1;
            this.BotaoBola46.Text = "46";
            this.BotaoBola46.UseVisualStyleBackColor = true;
            this.BotaoBola46.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola31
            // 
            this.BotaoBola31.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola31.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola31.Location = new System.Drawing.Point(8, 139);
            this.BotaoBola31.Name = "BotaoBola31";
            this.BotaoBola31.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola31.TabIndex = 1;
            this.BotaoBola31.Text = "31";
            this.BotaoBola31.UseVisualStyleBackColor = true;
            this.BotaoBola31.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola16
            // 
            this.BotaoBola16.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola16.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola16.Location = new System.Drawing.Point(8, 73);
            this.BotaoBola16.Name = "BotaoBola16";
            this.BotaoBola16.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola16.TabIndex = 1;
            this.BotaoBola16.Text = "16";
            this.BotaoBola16.UseVisualStyleBackColor = true;
            this.BotaoBola16.Click += new System.EventHandler(this.Button_Click);
            // 
            // BotaoBola1
            // 
            this.BotaoBola1.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BotaoBola1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BotaoBola1.Location = new System.Drawing.Point(8, 7);
            this.BotaoBola1.Name = "BotaoBola1";
            this.BotaoBola1.Size = new System.Drawing.Size(60, 60);
            this.BotaoBola1.TabIndex = 1;
            this.BotaoBola1.Text = "01";
            this.BotaoBola1.UseVisualStyleBackColor = true;
            this.BotaoBola1.Click += new System.EventHandler(this.Button_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.groupBox4);
            this.panel2.Location = new System.Drawing.Point(1022, 79);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(316, 155);
            this.panel2.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.textBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.textBox1.Location = new System.Drawing.Point(3, 3);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(311, 19);
            this.textBox1.TabIndex = 44;
            this.textBox1.Text = "INSIRA OS DETALHES DO SORTEIO";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            //this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.NomeEvento);
            this.groupBox4.Controls.Add(this.EdicaoEvento);
            this.groupBox4.Controls.Add(this.DescricaoPremio);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.TextoDescricaoPremio);
            this.groupBox4.Controls.Add(this.TextoEdicao);
            this.groupBox4.Controls.Add(this.NumeroPremio);
            this.groupBox4.Controls.Add(this.TextoPremio);
            this.groupBox4.Location = new System.Drawing.Point(3, 44);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(310, 108);
            this.groupBox4.TabIndex = 43;
            this.groupBox4.TabStop = false;
            //this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // NomeEvento
            // 
            this.NomeEvento.AutoSize = true;
            this.NomeEvento.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NomeEvento.Location = new System.Drawing.Point(42, 11);
            this.NomeEvento.Name = "NomeEvento";
            this.NomeEvento.Size = new System.Drawing.Size(236, 17);
            this.NomeEvento.TabIndex = 4;
            this.NomeEvento.Text = "PAROQUIA SANTA TEREZINHA";
            // 
            // EdicaoEvento
            // 
            this.EdicaoEvento.AutoSize = true;
            this.EdicaoEvento.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EdicaoEvento.Location = new System.Drawing.Point(42, 38);
            this.EdicaoEvento.Name = "EdicaoEvento";
            this.EdicaoEvento.Size = new System.Drawing.Size(77, 17);
            this.EdicaoEvento.TabIndex = 4;
            this.EdicaoEvento.Text = "015-2023";
            // 
            // DescricaoPremio
            // 
            this.DescricaoPremio.AutoSize = true;
            this.DescricaoPremio.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DescricaoPremio.Location = new System.Drawing.Point(106, 89);
            this.DescricaoPremio.Name = "DescricaoPremio";
            this.DescricaoPremio.Size = new System.Drawing.Size(94, 17);
            this.DescricaoPremio.TabIndex = 4;
            this.DescricaoPremio.Text = "2000 REAIS";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(2, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Evento:";
            // 
            // TextoDescricaoPremio
            // 
            this.TextoDescricaoPremio.AutoSize = true;
            this.TextoDescricaoPremio.Location = new System.Drawing.Point(1, 91);
            this.TextoDescricaoPremio.Name = "TextoDescricaoPremio";
            this.TextoDescricaoPremio.Size = new System.Drawing.Size(107, 13);
            this.TextoDescricaoPremio.TabIndex = 4;
            this.TextoDescricaoPremio.Text = "Descrição do prêmio:";
            // 
            // TextoEdicao
            // 
            this.TextoEdicao.AutoSize = true;
            this.TextoEdicao.Location = new System.Drawing.Point(1, 40);
            this.TextoEdicao.Name = "TextoEdicao";
            this.TextoEdicao.Size = new System.Drawing.Size(43, 13);
            this.TextoEdicao.TabIndex = 4;
            this.TextoEdicao.Text = "Edição:";
            // 
            // NumeroPremio
            // 
            this.NumeroPremio.AutoSize = true;
            this.NumeroPremio.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NumeroPremio.Location = new System.Drawing.Point(98, 66);
            this.NumeroPremio.Name = "NumeroPremio";
            this.NumeroPremio.Size = new System.Drawing.Size(17, 17);
            this.NumeroPremio.TabIndex = 4;
            this.NumeroPremio.Text = "1";
            // 
            // TextoPremio
            // 
            this.TextoPremio.AutoSize = true;
            this.TextoPremio.Location = new System.Drawing.Point(1, 68);
            this.TextoPremio.Name = "TextoPremio";
            this.TextoPremio.Size = new System.Drawing.Size(96, 13);
            this.TextoPremio.TabIndex = 4;
            this.TextoPremio.Text = "Número do prêmio:";
            // 
            // TempoDecorrido
            // 
            this.TempoDecorrido.AutoSize = true;
            this.TempoDecorrido.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TempoDecorrido.Location = new System.Drawing.Point(156, 488);
            this.TempoDecorrido.Name = "TempoDecorrido";
            this.TempoDecorrido.Size = new System.Drawing.Size(87, 31);
            this.TempoDecorrido.TabIndex = 6;
            this.TempoDecorrido.Text = "00:00";
            // 
            // TextoTempoDecorrido
            // 
            this.TextoTempoDecorrido.AutoSize = true;
            this.TextoTempoDecorrido.Location = new System.Drawing.Point(159, 473);
            this.TextoTempoDecorrido.Name = "TextoTempoDecorrido";
            this.TextoTempoDecorrido.Size = new System.Drawing.Size(90, 13);
            this.TextoTempoDecorrido.TabIndex = 5;
            this.TextoTempoDecorrido.Text = "Tempo decorrido:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(571, 373);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 25);
            this.label1.TabIndex = 3;
            // 
            // BotaoSairSistema
            // 
            this.BotaoSairSistema.Location = new System.Drawing.Point(1245, 11);
            this.BotaoSairSistema.Name = "BotaoSairSistema";
            this.BotaoSairSistema.Size = new System.Drawing.Size(95, 32);
            this.BotaoSairSistema.TabIndex = 6;
            this.BotaoSairSistema.Text = "Sair do Sitema";
            this.BotaoSairSistema.UseVisualStyleBackColor = true;
            this.BotaoSairSistema.Click += new System.EventHandler(this.button76_Click);
            // 
            // BotaoSortearBola
            // 
            this.BotaoSortearBola.Enabled = false;
            this.BotaoSortearBola.Location = new System.Drawing.Point(464, 7);
            this.BotaoSortearBola.Name = "BotaoSortearBola";
            this.BotaoSortearBola.Size = new System.Drawing.Size(56, 26);
            this.BotaoSortearBola.TabIndex = 8;
            this.BotaoSortearBola.Text = "Sortear";
            this.BotaoSortearBola.UseVisualStyleBackColor = true;
            this.BotaoSortearBola.Click += new System.EventHandler(this.Sortear_Click);
            // 
            // OrdemSorteio
            // 
            this.OrdemSorteio.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.OrdemSorteio.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrdemSorteio.Location = new System.Drawing.Point(10, 394);
            this.OrdemSorteio.Multiline = true;
            this.OrdemSorteio.Name = "OrdemSorteio";
            this.OrdemSorteio.ReadOnly = true;
            this.OrdemSorteio.Size = new System.Drawing.Size(999, 52);
            this.OrdemSorteio.TabIndex = 9;
            //this.OrdemSorteio.TextChanged += new System.EventHandler(this.OrdemSorteio_TextChanged);
            // 
            // validacao
            // 
            this.validacao.BackColor = System.Drawing.SystemColors.HotTrack;
            this.validacao.Controls.Add(this.CartelasValidadas);
            this.validacao.Controls.Add(this.BotaoApagarTudo);
            this.validacao.Controls.Add(this.UltimaValidada);
            this.validacao.Controls.Add(this.TotalValidada);
            this.validacao.Controls.Add(this.TextoTotal);
            this.validacao.Controls.Add(this.Lancamento);
            this.validacao.Controls.Add(this.Lote);
            this.validacao.Controls.Add(this.ValidarCartela);
            this.validacao.Controls.Add(this.TextoUltima);
            this.validacao.Controls.Add(this.TextoCartelaValidada);
            this.validacao.Controls.Add(this.TextoLancamento);
            this.validacao.Controls.Add(this.TextoLtoe);
            this.validacao.Controls.Add(this.BotaoExportarCSV);
            this.validacao.Controls.Add(this.TextoValidacao);
            this.validacao.Controls.Add(this.label21);
            this.validacao.Location = new System.Drawing.Point(1022, 245);
            this.validacao.Name = "validacao";
            this.validacao.Size = new System.Drawing.Size(316, 442);
            this.validacao.TabIndex = 3;
            // 
            // CartelasValidadas
            // 
            this.CartelasValidadas.FormattingEnabled = true;
            this.CartelasValidadas.HorizontalScrollbar = true;
            this.CartelasValidadas.Location = new System.Drawing.Point(11, 72);
            this.CartelasValidadas.MultiColumn = true;
            this.CartelasValidadas.Name = "CartelasValidadas";
            this.CartelasValidadas.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.CartelasValidadas.Size = new System.Drawing.Size(294, 316);
            this.CartelasValidadas.TabIndex = 24;
            //this.CartelasValidadas.SelectedIndexChanged += new System.EventHandler(this.listaValidadas_SelectedIndexChanged);
            // 
            // BotaoApagarTudo
            // 
            this.BotaoApagarTudo.Location = new System.Drawing.Point(120, 398);
            this.BotaoApagarTudo.Name = "BotaoApagarTudo";
            this.BotaoApagarTudo.Size = new System.Drawing.Size(91, 32);
            this.BotaoApagarTudo.TabIndex = 18;
            this.BotaoApagarTudo.Text = "Apagar Tudo";
            this.BotaoApagarTudo.UseVisualStyleBackColor = true;
            // 
            // UltimaValidada
            // 
            this.UltimaValidada.AutoSize = true;
            this.UltimaValidada.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UltimaValidada.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.UltimaValidada.Location = new System.Drawing.Point(58, 415);
            this.UltimaValidada.Name = "UltimaValidada";
            this.UltimaValidada.Size = new System.Drawing.Size(52, 15);
            this.UltimaValidada.TabIndex = 23;
            this.UltimaValidada.Text = "1540-5";
            // 
            // TotalValidada
            // 
            this.TotalValidada.AutoSize = true;
            this.TotalValidada.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalValidada.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TotalValidada.Location = new System.Drawing.Point(72, 397);
            this.TotalValidada.Name = "TotalValidada";
            this.TotalValidada.Size = new System.Drawing.Size(39, 15);
            this.TotalValidada.TabIndex = 22;
            this.TotalValidada.Text = "5625";
            // 
            // TextoTotal
            // 
            this.TextoTotal.AutoSize = true;
            this.TextoTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextoTotal.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TextoTotal.Location = new System.Drawing.Point(9, 397);
            this.TextoTotal.Name = "TextoTotal";
            this.TextoTotal.Size = new System.Drawing.Size(37, 15);
            this.TextoTotal.TabIndex = 21;
            this.TextoTotal.Text = "Total:";
            // 
            // Lancamento
            // 
            this.Lancamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lancamento.Location = new System.Drawing.Point(138, 39);
            this.Lancamento.Name = "Lancamento";
            this.Lancamento.Size = new System.Drawing.Size(47, 23);
            this.Lancamento.TabIndex = 19;
            // 
            // Lote
            // 
            this.Lote.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lote.Location = new System.Drawing.Point(48, 39);
            this.Lote.Name = "Lote";
            this.Lote.Size = new System.Drawing.Size(47, 23);
            this.Lote.TabIndex = 18;
            // 
            // ValidarCartela
            // 
            this.ValidarCartela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ValidarCartela.Location = new System.Drawing.Point(247, 39);
            this.ValidarCartela.Name = "ValidarCartela";
            this.ValidarCartela.Size = new System.Drawing.Size(58, 23);
            this.ValidarCartela.TabIndex = 17;
            // 
            // TextoUltima
            // 
            this.TextoUltima.AutoSize = true;
            this.TextoUltima.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextoUltima.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TextoUltima.Location = new System.Drawing.Point(9, 414);
            this.TextoUltima.Name = "TextoUltima";
            this.TextoUltima.Size = new System.Drawing.Size(46, 15);
            this.TextoUltima.TabIndex = 20;
            this.TextoUltima.Text = "Última:";
            // 
            // TextoCartelaValidada
            // 
            this.TextoCartelaValidada.AutoSize = true;
            this.TextoCartelaValidada.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextoCartelaValidada.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TextoCartelaValidada.Location = new System.Drawing.Point(189, 42);
            this.TextoCartelaValidada.Name = "TextoCartelaValidada";
            this.TextoCartelaValidada.Size = new System.Drawing.Size(57, 17);
            this.TextoCartelaValidada.TabIndex = 16;
            this.TextoCartelaValidada.Text = "Cartela:";
            // 
            // TextoLancamento
            // 
            this.TextoLancamento.AutoSize = true;
            this.TextoLancamento.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextoLancamento.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TextoLancamento.Location = new System.Drawing.Point(101, 42);
            this.TextoLancamento.Name = "TextoLancamento";
            this.TextoLancamento.Size = new System.Drawing.Size(36, 17);
            this.TextoLancamento.TabIndex = 7;
            this.TextoLancamento.Text = "Lan:";
            // 
            // TextoLtoe
            // 
            this.TextoLtoe.AutoSize = true;
            this.TextoLtoe.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextoLtoe.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TextoLtoe.Location = new System.Drawing.Point(7, 42);
            this.TextoLtoe.Name = "TextoLtoe";
            this.TextoLtoe.Size = new System.Drawing.Size(40, 17);
            this.TextoLtoe.TabIndex = 6;
            this.TextoLtoe.Text = "Lote:";
            // 
            // BotaoExportarCSV
            // 
            this.BotaoExportarCSV.Location = new System.Drawing.Point(219, 398);
            this.BotaoExportarCSV.Name = "BotaoExportarCSV";
            this.BotaoExportarCSV.Size = new System.Drawing.Size(86, 31);
            this.BotaoExportarCSV.TabIndex = 15;
            this.BotaoExportarCSV.Text = "Exportar CSV";
            this.BotaoExportarCSV.UseVisualStyleBackColor = true;
            // 
            // TextoValidacao
            // 
            this.TextoValidacao.AutoSize = true;
            this.TextoValidacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextoValidacao.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.TextoValidacao.Location = new System.Drawing.Point(106, 10);
            this.TextoValidacao.Name = "TextoValidacao";
            this.TextoValidacao.Size = new System.Drawing.Size(111, 20);
            this.TextoValidacao.TabIndex = 4;
            this.TextoValidacao.Text = "VALIDAÇÃO";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(21, 17);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(0, 25);
            this.label21.TabIndex = 3;
            // 
            // RadioBotaoPedraPedra
            // 
            this.RadioBotaoPedraPedra.AutoSize = true;
            this.RadioBotaoPedraPedra.Location = new System.Drawing.Point(380, 11);
            this.RadioBotaoPedraPedra.Name = "RadioBotaoPedraPedra";
            this.RadioBotaoPedraPedra.Size = new System.Drawing.Size(81, 17);
            this.RadioBotaoPedraPedra.TabIndex = 11;
            this.RadioBotaoPedraPedra.Text = "Bolo a bola:";
            this.RadioBotaoPedraPedra.UseVisualStyleBackColor = true;
            this.RadioBotaoPedraPedra.CheckedChanged += new System.EventHandler(this.RadioBotaoPedraPedra_CheckedChanged);
            // 
            // radioButton3RadioBotaoAutomatico
            // 
            this.radioButton3RadioBotaoAutomatico.AutoSize = true;
            this.radioButton3RadioBotaoAutomatico.Checked = true;
            this.radioButton3RadioBotaoAutomatico.Location = new System.Drawing.Point(124, 11);
            this.radioButton3RadioBotaoAutomatico.Name = "radioButton3RadioBotaoAutomatico";
            this.radioButton3RadioBotaoAutomatico.Size = new System.Drawing.Size(81, 17);
            this.radioButton3RadioBotaoAutomatico.TabIndex = 11;
            this.radioButton3RadioBotaoAutomatico.TabStop = true;
            this.radioButton3RadioBotaoAutomatico.Text = "Automático:";
            this.radioButton3RadioBotaoAutomatico.UseVisualStyleBackColor = true;
            this.radioButton3RadioBotaoAutomatico.CheckedChanged += new System.EventHandler(this.radioButton3RadioBotaoAutomatico_CheckedChanged);
            // 
            // RadioBotaoManual
            // 
            this.RadioBotaoManual.AutoSize = true;
            this.RadioBotaoManual.Location = new System.Drawing.Point(269, 11);
            this.RadioBotaoManual.Name = "RadioBotaoManual";
            this.RadioBotaoManual.Size = new System.Drawing.Size(63, 17);
            this.RadioBotaoManual.TabIndex = 11;
            this.RadioBotaoManual.Text = "Manual:";
            this.RadioBotaoManual.UseVisualStyleBackColor = true;
            this.RadioBotaoManual.CheckedChanged += new System.EventHandler(this.RadioBotaoManual_CheckedChanged);
            // 
            // TextoModoSorteio
            // 
            this.TextoModoSorteio.AutoSize = true;
            this.TextoModoSorteio.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextoModoSorteio.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.TextoModoSorteio.Location = new System.Drawing.Point(9, 11);
            this.TextoModoSorteio.Name = "TextoModoSorteio";
            this.TextoModoSorteio.Size = new System.Drawing.Size(114, 17);
            this.TextoModoSorteio.TabIndex = 10;
            this.TextoModoSorteio.Text = "Modo de sorteio:";
            // 
            // CaixaInsercaoManual
            // 
            this.CaixaInsercaoManual.Enabled = false;
            this.CaixaInsercaoManual.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CaixaInsercaoManual.Location = new System.Drawing.Point(333, 8);
            this.CaixaInsercaoManual.MaxLength = 2;
            this.CaixaInsercaoManual.Name = "CaixaInsercaoManual";
            this.CaixaInsercaoManual.Size = new System.Drawing.Size(29, 24);
            this.CaixaInsercaoManual.TabIndex = 12;
            this.CaixaInsercaoManual.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            //this.CaixaInsercaoManual.TextChanged += new System.EventHandler(this.CaixaInsercaoManual_TextChanged);
            this.CaixaInsercaoManual.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // AjustarTempoBola
            // 
            this.AjustarTempoBola.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AjustarTempoBola.Location = new System.Drawing.Point(205, 9);
            this.AjustarTempoBola.Name = "AjustarTempoBola";
            this.AjustarTempoBola.Size = new System.Drawing.Size(42, 23);
            this.AjustarTempoBola.TabIndex = 13;
            this.AjustarTempoBola.Value = new decimal(new int[] {
            11,
            0,
            0,
            0});
            //this.AjustarTempoBola.ValueChanged += new System.EventHandler(this.AjustarTempoBola_ValueChanged);
            this.AjustarTempoBola.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.numericUpDown1_KeyPress);
            // 
            // RadioBotaoLinha
            // 
            this.RadioBotaoLinha.AutoSize = true;
            this.RadioBotaoLinha.Checked = true;
            this.RadioBotaoLinha.Location = new System.Drawing.Point(82, 12);
            this.RadioBotaoLinha.Name = "RadioBotaoLinha";
            this.RadioBotaoLinha.Size = new System.Drawing.Size(80, 17);
            this.RadioBotaoLinha.TabIndex = 11;
            this.RadioBotaoLinha.TabStop = true;
            this.RadioBotaoLinha.Text = "Linha cheia";
            this.RadioBotaoLinha.UseVisualStyleBackColor = true;
            // 
            // RadioBotaoCheia
            // 
            this.RadioBotaoCheia.AutoSize = true;
            this.RadioBotaoCheia.Location = new System.Drawing.Point(167, 12);
            this.RadioBotaoCheia.Name = "RadioBotaoCheia";
            this.RadioBotaoCheia.Size = new System.Drawing.Size(87, 17);
            this.RadioBotaoCheia.TabIndex = 11;
            this.RadioBotaoCheia.Text = "Cartela cheia";
            this.RadioBotaoCheia.UseVisualStyleBackColor = true;
            // 
            // novoToolStripButton
            // 
            this.novoToolStripButton.Name = "novoToolStripButton";
            this.novoToolStripButton.Size = new System.Drawing.Size(23, 23);
            // 
            // abrirToolStripButton
            // 
            this.abrirToolStripButton.Name = "abrirToolStripButton";
            this.abrirToolStripButton.Size = new System.Drawing.Size(23, 23);
            // 
            // salvarToolStripButton
            // 
            this.salvarToolStripButton.Name = "salvarToolStripButton";
            this.salvarToolStripButton.Size = new System.Drawing.Size(23, 23);
            // 
            // imprimirToolStripButton
            // 
            this.imprimirToolStripButton.Name = "imprimirToolStripButton";
            this.imprimirToolStripButton.Size = new System.Drawing.Size(23, 23);
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(6, 6);
            // 
            // recortarToolStripButton
            // 
            this.recortarToolStripButton.Name = "recortarToolStripButton";
            this.recortarToolStripButton.Size = new System.Drawing.Size(23, 23);
            // 
            // copiarToolStripButton
            // 
            this.copiarToolStripButton.Name = "copiarToolStripButton";
            this.copiarToolStripButton.Size = new System.Drawing.Size(23, 23);
            // 
            // colarToolStripButton
            // 
            this.colarToolStripButton.Name = "colarToolStripButton";
            this.colarToolStripButton.Size = new System.Drawing.Size(23, 23);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // ajudaToolStripButton
            // 
            this.ajudaToolStripButton.Name = "ajudaToolStripButton";
            this.ajudaToolStripButton.Size = new System.Drawing.Size(23, 23);
            // 
            // PainelBarraWindows
            // 
            this.PainelBarraWindows.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.PainelBarraWindows.Controls.Add(this.TextoBarraInferior);
            this.PainelBarraWindows.Location = new System.Drawing.Point(0, 699);
            this.PainelBarraWindows.Name = "PainelBarraWindows";
            this.PainelBarraWindows.Size = new System.Drawing.Size(1351, 30);
            this.PainelBarraWindows.TabIndex = 18;
            // 
            // TextoBarraInferior
            // 
            this.TextoBarraInferior.AutoSize = true;
            this.TextoBarraInferior.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.TextoBarraInferior.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextoBarraInferior.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.TextoBarraInferior.Location = new System.Drawing.Point(543, 5);
            this.TextoBarraInferior.Name = "TextoBarraInferior";
            this.TextoBarraInferior.Size = new System.Drawing.Size(228, 20);
            this.TextoBarraInferior.TabIndex = 0;
            this.TextoBarraInferior.Text = "Todo arraial tem Super Bingão!";
            // 
            // BotaoEncerrarSorteio
            // 
            this.BotaoEncerrarSorteio.Location = new System.Drawing.Point(286, 656);
            this.BotaoEncerrarSorteio.Name = "BotaoEncerrarSorteio";
            this.BotaoEncerrarSorteio.Size = new System.Drawing.Size(112, 32);
            this.BotaoEncerrarSorteio.TabIndex = 19;
            this.BotaoEncerrarSorteio.Text = "Encerrar Sorteio";
            this.BotaoEncerrarSorteio.UseVisualStyleBackColor = true;
            //this.BotaoEncerrarSorteio.Click += new System.EventHandler(this.BotaoEncerrarSorteio_Click);
            // 
            // BotaoIniciarPausarSorteio
            // 
            this.BotaoIniciarPausarSorteio.Location = new System.Drawing.Point(12, 656);
            this.BotaoIniciarPausarSorteio.Name = "BotaoIniciarPausarSorteio";
            this.BotaoIniciarPausarSorteio.Size = new System.Drawing.Size(134, 32);
            this.BotaoIniciarPausarSorteio.TabIndex = 20;
            this.BotaoIniciarPausarSorteio.Text = "Iniciar Sorteio";
            this.BotaoIniciarPausarSorteio.UseVisualStyleBackColor = true;
            this.BotaoIniciarPausarSorteio.Click += new System.EventHandler(this.BotaoIniciarPausarSorteio_Click);
            // 
            // TextoMarcacao
            // 
            this.TextoMarcacao.AutoSize = true;
            this.TextoMarcacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextoMarcacao.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.TextoMarcacao.Location = new System.Drawing.Point(4, 12);
            this.TextoMarcacao.Name = "TextoMarcacao";
            this.TextoMarcacao.Size = new System.Drawing.Size(74, 17);
            this.TextoMarcacao.TabIndex = 10;
            this.TextoMarcacao.Text = "Marcação:";
            // 
            // TextoBolasSorteadas
            // 
            this.TextoBolasSorteadas.AutoSize = true;
            this.TextoBolasSorteadas.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextoBolasSorteadas.Location = new System.Drawing.Point(8, 455);
            this.TextoBolasSorteadas.Name = "TextoBolasSorteadas";
            this.TextoBolasSorteadas.Size = new System.Drawing.Size(114, 17);
            this.TextoBolasSorteadas.TabIndex = 23;
            this.TextoBolasSorteadas.Text = "Bolas sorteadas:";
            // 
            // TextoBolasRestantes
            // 
            this.TextoBolasRestantes.AutoSize = true;
            this.TextoBolasRestantes.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextoBolasRestantes.Location = new System.Drawing.Point(8, 477);
            this.TextoBolasRestantes.Name = "TextoBolasRestantes";
            this.TextoBolasRestantes.Size = new System.Drawing.Size(110, 17);
            this.TextoBolasRestantes.TabIndex = 24;
            this.TextoBolasRestantes.Text = "Bolas restantes:";
            // 
            // ListaCartelasPeQuente
            // 
            this.ListaCartelasPeQuente.FormattingEnabled = true;
            this.ListaCartelasPeQuente.Location = new System.Drawing.Point(626, 489);
            this.ListaCartelasPeQuente.Name = "ListaCartelasPeQuente";
            this.ListaCartelasPeQuente.Size = new System.Drawing.Size(385, 199);
            this.ListaCartelasPeQuente.TabIndex = 25;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(623, 469);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(136, 17);
            this.label30.TabIndex = 22;
            this.label30.Text = "Cartelas Pé Quente:";
            // 
            // TotalSorteadas
            // 
            this.TotalSorteadas.AutoSize = true;
            this.TotalSorteadas.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalSorteadas.Location = new System.Drawing.Point(133, 455);
            this.TotalSorteadas.Name = "TotalSorteadas";
            this.TotalSorteadas.Size = new System.Drawing.Size(17, 17);
            this.TotalSorteadas.TabIndex = 26;
            this.TotalSorteadas.Text = "0";
            // 
            // TotalRestantes
            // 
            this.TotalRestantes.AutoSize = true;
            this.TotalRestantes.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalRestantes.Location = new System.Drawing.Point(133, 477);
            this.TotalRestantes.Name = "TotalRestantes";
            this.TotalRestantes.Size = new System.Drawing.Size(17, 17);
            this.TotalRestantes.TabIndex = 27;
            this.TotalRestantes.Text = "0";
            //this.TotalRestantes.Click += new System.EventHandler(this.TotalRestantes_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1265, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 15);
            this.label2.TabIndex = 28;
            this.label2.Text = "Versão 1.0.0";
            // 
            // TextoCartelasPeFrio
            // 
            this.TextoCartelasPeFrio.AutoSize = true;
            this.TextoCartelasPeFrio.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextoCartelasPeFrio.Location = new System.Drawing.Point(9, 505);
            this.TextoCartelasPeFrio.Name = "TextoCartelasPeFrio";
            this.TextoCartelasPeFrio.Size = new System.Drawing.Size(113, 17);
            this.TextoCartelasPeFrio.TabIndex = 24;
            this.TextoCartelasPeFrio.Text = "Cartelas Pé Frio:";
            // 
            // ListaCartelasPeFrio
            // 
            this.ListaCartelasPeFrio.FormattingEnabled = true;
            this.ListaCartelasPeFrio.Location = new System.Drawing.Point(10, 525);
            this.ListaCartelasPeFrio.Name = "ListaCartelasPeFrio";
            this.ListaCartelasPeFrio.Size = new System.Drawing.Size(383, 121);
            this.ListaCartelasPeFrio.TabIndex = 31;
            // 
            // BotaoPrepararSorteio
            // 
            this.BotaoPrepararSorteio.Location = new System.Drawing.Point(154, 656);
            this.BotaoPrepararSorteio.Name = "BotaoPrepararSorteio";
            this.BotaoPrepararSorteio.Size = new System.Drawing.Size(119, 32);
            this.BotaoPrepararSorteio.TabIndex = 19;
            this.BotaoPrepararSorteio.Text = "Preparar Sorteio";
            this.BotaoPrepararSorteio.UseVisualStyleBackColor = true;
            this.BotaoPrepararSorteio.Click += new System.EventHandler(this.BotaoPrepararSorteio_Click);
            // 
            // BotaoConferirCartela
            // 
            this.BotaoConferirCartela.Location = new System.Drawing.Point(903, 453);
            this.BotaoConferirCartela.Name = "BotaoConferirCartela";
            this.BotaoConferirCartela.Size = new System.Drawing.Size(107, 32);
            this.BotaoConferirCartela.TabIndex = 32;
            this.BotaoConferirCartela.Text = "Conferir Cartela";
            this.BotaoConferirCartela.UseVisualStyleBackColor = true;
            // 
            // TextoApresentar
            // 
            this.TextoApresentar.AutoSize = true;
            this.TextoApresentar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextoApresentar.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.TextoApresentar.Location = new System.Drawing.Point(1, 12);
            this.TextoApresentar.Name = "TextoApresentar";
            this.TextoApresentar.Size = new System.Drawing.Size(82, 17);
            this.TextoApresentar.TabIndex = 10;
            this.TextoApresentar.Text = "Apresentar:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.label6.Location = new System.Drawing.Point(212, 355);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(21, 31);
            this.label6.TabIndex = 17;
            this.label6.Text = "|";
            // 
            // BotaoBrindes
            // 
            this.BotaoBrindes.Location = new System.Drawing.Point(281, 487);
            this.BotaoBrindes.Name = "BotaoBrindes";
            this.BotaoBrindes.Size = new System.Drawing.Size(112, 32);
            this.BotaoBrindes.TabIndex = 35;
            this.BotaoBrindes.Text = "Sorteio de Brindes";
            this.BotaoBrindes.UseVisualStyleBackColor = true;
            //this.BotaoBrindes.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // checkBox_Som
            // 
            this.checkBox_Som.AutoSize = true;
            this.checkBox_Som.Checked = true;
            this.checkBox_Som.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_Som.Location = new System.Drawing.Point(83, 14);
            this.checkBox_Som.Name = "checkBox_Som";
            this.checkBox_Som.Size = new System.Drawing.Size(47, 17);
            this.checkBox_Som.TabIndex = 38;
            this.checkBox_Som.Text = "Som";
            this.checkBox_Som.UseVisualStyleBackColor = true;
            //this.checkBox_Som.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox_img
            // 
            this.checkBox_img.AutoSize = true;
            this.checkBox_img.Checked = true;
            this.checkBox_img.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox_img.Location = new System.Drawing.Point(133, 14);
            this.checkBox_img.Name = "checkBox_img";
            this.checkBox_img.Size = new System.Drawing.Size(63, 17);
            this.checkBox_img.TabIndex = 39;
            this.checkBox_img.Text = "Imagem";
            this.checkBox_img.UseVisualStyleBackColor = true;
            //this.checkBox_img.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TextoModoSorteio);
            this.groupBox1.Controls.Add(this.RadioBotaoManual);
            this.groupBox1.Controls.Add(this.RadioBotaoPedraPedra);
            this.groupBox1.Controls.Add(this.radioButton3RadioBotaoAutomatico);
            this.groupBox1.Controls.Add(this.AjustarTempoBola);
            this.groupBox1.Controls.Add(this.BotaoSortearBola);
            this.groupBox1.Controls.Add(this.CaixaInsercaoManual);
            this.groupBox1.Location = new System.Drawing.Point(482, 353);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(527, 37);
            this.groupBox1.TabIndex = 40;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.RadioBotaoLinha);
            this.groupBox2.Controls.Add(this.RadioBotaoCheia);
            this.groupBox2.Controls.Add(this.TextoMarcacao);
            this.groupBox2.Location = new System.Drawing.Point(220, 353);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(256, 37);
            this.groupBox2.TabIndex = 41;
            this.groupBox2.TabStop = false;
            //this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.TextoApresentar);
            this.groupBox3.Controls.Add(this.checkBox_Som);
            this.groupBox3.Controls.Add(this.checkBox_img);
            this.groupBox3.Location = new System.Drawing.Point(11, 353);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(202, 37);
            this.groupBox3.TabIndex = 42;
            this.groupBox3.TabStop = false;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // PainelUltimaBola
            // 
            this.PainelUltimaBola.BackgroundImage = global::SuperBingao.Properties.Resources.bola211x211;
            this.PainelUltimaBola.Controls.Add(this.TextoUltimaBola);
            this.PainelUltimaBola.Location = new System.Drawing.Point(404, 477);
            this.PainelUltimaBola.Name = "PainelUltimaBola";
            this.PainelUltimaBola.Size = new System.Drawing.Size(211, 211);
            this.PainelUltimaBola.TabIndex = 37;
            // 
            // TextoUltimaBola
            // 
            this.TextoUltimaBola.AccessibleRole = System.Windows.Forms.AccessibleRole.Grip;
            this.TextoUltimaBola.AutoSize = true;
            this.TextoUltimaBola.BackColor = System.Drawing.Color.Transparent;
            this.TextoUltimaBola.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextoUltimaBola.ForeColor = System.Drawing.Color.Red;
            this.TextoUltimaBola.Location = new System.Drawing.Point(15, 39);
            this.TextoUltimaBola.Name = "TextoUltimaBola";
            this.TextoUltimaBola.Size = new System.Drawing.Size(189, 135);
            this.TextoUltimaBola.TabIndex = 36;
            this.TextoUltimaBola.Text = "    ";
            this.TextoUltimaBola.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            //this.TextoUltimaBola.Click += new System.EventHandler(this.TextoUltimaBola_Click_1);
            // 
            // ImageLogo
            // 
            this.ImageLogo.ImageLocation = "C:\\SuperBingao\\Imagens\\logo.png";
            this.ImageLogo.Location = new System.Drawing.Point(1022, 11);
            this.ImageLogo.Name = "ImageLogo";
            this.ImageLogo.Size = new System.Drawing.Size(170, 60);
            this.ImageLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.ImageLogo.TabIndex = 7;
            this.ImageLogo.TabStop = false;
            this.ImageLogo.WaitOnLoad = true;
            //this.ImageLogo.Click += new System.EventHandler(this.ImageLogo_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.TempoDecorrido);
            this.Controls.Add(this.TextoTempoDecorrido);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.PainelUltimaBola);
            this.Controls.Add(this.TotalSorteadas);
            this.Controls.Add(this.BotaoBrindes);
            this.Controls.Add(this.BotaoConferirCartela);
            this.Controls.Add(this.ListaCartelasPeFrio);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ImageLogo);
            this.Controls.Add(this.TotalRestantes);
            this.Controls.Add(this.ListaCartelasPeQuente);
            this.Controls.Add(this.TextoCartelasPeFrio);
            this.Controls.Add(this.TextoBolasRestantes);
            this.Controls.Add(this.TextoBolasSorteadas);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.BotaoIniciarPausarSorteio);
            this.Controls.Add(this.BotaoPrepararSorteio);
            this.Controls.Add(this.BotaoEncerrarSorteio);
            this.Controls.Add(this.BotaoSairSistema);
            this.Controls.Add(this.PainelBarraWindows);
            this.Controls.Add(this.validacao);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.OrdemSorteio);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "Form1";
            this.Text = "SuperBingão";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            //this.Click += new System.EventHandler(this.Form1_Click);
            this.Enter += new System.EventHandler(this.EntradaManual_TextChanged);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.validacao.ResumeLayout(false);
            this.validacao.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AjustarTempoBola)).EndInit();
            this.PainelBarraWindows.ResumeLayout(false);
            this.PainelBarraWindows.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.PainelUltimaBola.ResumeLayout(false);
            this.PainelUltimaBola.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ImageLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button BotaoBola75;
        private System.Windows.Forms.Button BotaoBola60;
        private System.Windows.Forms.Button BotaoBola45;
        private System.Windows.Forms.Button BotaoBola30;
        private System.Windows.Forms.Button BotaoBola15;
        private System.Windows.Forms.Button BotaoBola74;
        private System.Windows.Forms.Button BotaoBola59;
        private System.Windows.Forms.Button BotaoBola44;
        private System.Windows.Forms.Button BotaoBola29;
        private System.Windows.Forms.Button BotaoBola14;
        private System.Windows.Forms.Button BotaoBola73;
        private System.Windows.Forms.Button BotaoBola58;
        private System.Windows.Forms.Button BotaoBola43;
        private System.Windows.Forms.Button BotaoBola28;
        private System.Windows.Forms.Button BotaoBola13;
        private System.Windows.Forms.Button BotaoBola72;
        private System.Windows.Forms.Button BotaoBola57;
        private System.Windows.Forms.Button BotaoBola42;
        private System.Windows.Forms.Button BotaoBola27;
        private System.Windows.Forms.Button BotaoBola12;
        private System.Windows.Forms.Button BotaoBola71;
        private System.Windows.Forms.Button BotaoBola56;
        private System.Windows.Forms.Button BotaoBola41;
        private System.Windows.Forms.Button BotaoBola26;
        private System.Windows.Forms.Button BotaoBola11;
        private System.Windows.Forms.Button BotaoBola70;
        private System.Windows.Forms.Button BotaoBola55;
        private System.Windows.Forms.Button BotaoBola40;
        private System.Windows.Forms.Button BotaoBola25;
        private System.Windows.Forms.Button BotaoBola10;
        private System.Windows.Forms.Button BotaoBola69;
        private System.Windows.Forms.Button BotaoBola54;
        private System.Windows.Forms.Button BotaoBola39;
        private System.Windows.Forms.Button BotaoBola24;
        private System.Windows.Forms.Button BotaoBola9;
        private System.Windows.Forms.Button BotaoBola68;
        private System.Windows.Forms.Button BotaoBola53;
        private System.Windows.Forms.Button BotaoBola38;
        private System.Windows.Forms.Button BotaoBola23;
        private System.Windows.Forms.Button BotaoBola8;
        private System.Windows.Forms.Button BotaoBola67;
        private System.Windows.Forms.Button BotaoBola52;
        private System.Windows.Forms.Button BotaoBola37;
        private System.Windows.Forms.Button BotaoBola22;
        private System.Windows.Forms.Button BotaoBola7;
        private System.Windows.Forms.Button BotaoBola66;
        private System.Windows.Forms.Button BotaoBola51;
        private System.Windows.Forms.Button BotaoBola36;
        private System.Windows.Forms.Button BotaoBola21;
        private System.Windows.Forms.Button BotaoBola6;
        private System.Windows.Forms.Button BotaoBola65;
        private System.Windows.Forms.Button BotaoBola50;
        private System.Windows.Forms.Button BotaoBola35;
        private System.Windows.Forms.Button BotaoBola20;
        private System.Windows.Forms.Button BotaoBola5;
        private System.Windows.Forms.Button BotaoBola64;
        private System.Windows.Forms.Button BotaoBola49;
        private System.Windows.Forms.Button BotaoBola34;
        private System.Windows.Forms.Button BotaoBola19;
        private System.Windows.Forms.Button BotaoBola4;
        private System.Windows.Forms.Button BotaoBola63;
        private System.Windows.Forms.Button BotaoBola48;
        private System.Windows.Forms.Button BotaoBola33;
        private System.Windows.Forms.Button BotaoBola18;
        private System.Windows.Forms.Button BotaoBola3;
        private System.Windows.Forms.Button BotaoBola62;
        private System.Windows.Forms.Button BotaoBola47;
        private System.Windows.Forms.Button BotaoBola32;
        private System.Windows.Forms.Button BotaoBola17;
        private System.Windows.Forms.Button BotaoBola2;
        private System.Windows.Forms.Button BotaoBola61;
        private System.Windows.Forms.Button BotaoBola46;
        private System.Windows.Forms.Button BotaoBola31;
        private System.Windows.Forms.Button BotaoBola16;
        private System.Windows.Forms.Button BotaoBola1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label TextoEdicao;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button BotaoSairSistema;
        private System.Windows.Forms.Button BotaoSortearBola;
        private System.Windows.Forms.TextBox OrdemSorteio;
        private System.Windows.Forms.Label TextoPremio;
        private System.Windows.Forms.Label TextoDescricaoPremio;
        private System.Windows.Forms.Label DescricaoPremio;
        private System.Windows.Forms.Label NumeroPremio;
        private System.Windows.Forms.Label EdicaoEvento;
        private System.Windows.Forms.Label NomeEvento;
        private System.Windows.Forms.Panel validacao;
        private System.Windows.Forms.Label TextoValidacao;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.RadioButton RadioBotaoPedraPedra;
        private System.Windows.Forms.RadioButton radioButton3RadioBotaoAutomatico;
        private System.Windows.Forms.RadioButton RadioBotaoManual;
        private System.Windows.Forms.Label TextoModoSorteio;
        private System.Windows.Forms.TextBox CaixaInsercaoManual;
        private System.Windows.Forms.NumericUpDown AjustarTempoBola;
        private System.Windows.Forms.Button BotaoExportarCSV;
        private System.Windows.Forms.RadioButton RadioBotaoLinha;
        private System.Windows.Forms.RadioButton RadioBotaoCheia;
        private System.Windows.Forms.ToolStripButton novoToolStripButton;
        private System.Windows.Forms.ToolStripButton abrirToolStripButton;
        private System.Windows.Forms.ToolStripButton salvarToolStripButton;
        private System.Windows.Forms.ToolStripButton imprimirToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripButton recortarToolStripButton;
        private System.Windows.Forms.ToolStripButton copiarToolStripButton;
        private System.Windows.Forms.ToolStripButton colarToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton ajudaToolStripButton;
        private System.Windows.Forms.Button BotaoApagarTudo;
        private System.Windows.Forms.Label UltimaValidada;
        private System.Windows.Forms.Label TotalValidada;
        private System.Windows.Forms.Label TextoTotal;
        private System.Windows.Forms.TextBox Lancamento;
        private System.Windows.Forms.TextBox Lote;
        private System.Windows.Forms.TextBox ValidarCartela;
        private System.Windows.Forms.Label TextoUltima;
        private System.Windows.Forms.Label TextoCartelaValidada;
        private System.Windows.Forms.Label TextoLancamento;
        private System.Windows.Forms.Label TextoLtoe;
        private System.Windows.Forms.Panel PainelBarraWindows;
        private System.Windows.Forms.ListBox CartelasValidadas;
        private System.Windows.Forms.Button BotaoEncerrarSorteio;
        private System.Windows.Forms.Button BotaoIniciarPausarSorteio;
        private System.Windows.Forms.Label TextoMarcacao;
        private System.Windows.Forms.Label TextoBolasSorteadas;
        private System.Windows.Forms.Label TextoBolasRestantes;
        private System.Windows.Forms.ListBox ListaCartelasPeQuente;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label TotalSorteadas;
        private System.Windows.Forms.Label TotalRestantes;
        private System.Windows.Forms.Label TempoDecorrido;
        private System.Windows.Forms.Label TextoTempoDecorrido;
        private System.Windows.Forms.PictureBox ImageLogo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label TextoCartelasPeFrio;
        private System.Windows.Forms.ListBox ListaCartelasPeFrio;
        private System.Windows.Forms.Label TextoBarraInferior;
        private System.Windows.Forms.Button BotaoPrepararSorteio;
        private System.Windows.Forms.Button BotaoConferirCartela;
        private System.Windows.Forms.Label TextoApresentar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button BotaoBrindes;
        private System.Windows.Forms.Panel PainelUltimaBola;
        private System.Windows.Forms.CheckBox checkBox_Som;
        private System.Windows.Forms.CheckBox checkBox_img;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.Label TextoUltimaBola;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}

